import java.util.*;

public class Training {
	private List<String>Exos=new ArrayList<>();
	private Exercices Exercices;

	public List<String> getExos() {
		return Exos;
	}

	public void setExos(List<String> exos) {
		Exos = exos;
	}
}